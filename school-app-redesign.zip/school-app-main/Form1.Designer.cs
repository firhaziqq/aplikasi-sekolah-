namespace SchoolApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        // Layout saja. Warna & style diatur di Form1.Theme.cs (ApplyTheme).
        private void InitializeComponent()
        {
            pnlNav = new Panel();
            lblAppName = new Label();
            btnNavStudent = new Button();
            btnNavVisitor = new Button();
            pnlStudent = new Panel();
            pnlVisitor = new Panel();

            pnlStudentCard = new Panel();
            label1 = new Label();
            label2 = new Label();
            lblClass = new Label();
            lblAddress = new Label();
            txtName = new TextBox();
            txtNIS = new TextBox();
            txtClass = new TextBox();
            txtAddress = new TextBox();
            txtSearchStudent = new TextBox();
            btnSave = new Button();
            btnUpdateStudent = new Button();
            btnDeleteStudent = new Button();
            btnClearStudent = new Button();
            dgvData = new DataGridView();

            pnlVisitorCard = new Panel();
            label3 = new Label();
            label4 = new Label();
            txtVisitors = new TextBox();
            txtInstitution = new TextBox();
            btnSaveVisitors = new Button();
            btnUpdateVisitors = new Button();
            btnDeleteVisitors = new Button();
            btnClearVisitor = new Button();
            dgvVisitors = new DataGridView();

            ((System.ComponentModel.ISupportInitialize)dgvData).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvVisitors).BeginInit();
            pnlNav.SuspendLayout();
            pnlStudent.SuspendLayout();
            pnlStudentCard.SuspendLayout();
            pnlVisitor.SuspendLayout();
            pnlVisitorCard.SuspendLayout();
            SuspendLayout();
            //
            // pnlNav
            //
            pnlNav.Controls.Add(btnNavVisitor);
            pnlNav.Controls.Add(btnNavStudent);
            pnlNav.Controls.Add(lblAppName);
            pnlNav.Dock = DockStyle.Top;
            pnlNav.Name = "pnlNav";
            pnlNav.Size = new Size(960, 64);
            pnlNav.TabIndex = 0;
            //
            // lblAppName
            //
            lblAppName.AutoSize = true;
            lblAppName.Location = new Point(22, 18);
            lblAppName.Name = "lblAppName";
            lblAppName.TabIndex = 0;
            lblAppName.Text = "SchoolApp";
            //
            // btnNavStudent
            //
            btnNavStudent.Location = new Point(220, 16);
            btnNavStudent.Name = "btnNavStudent";
            btnNavStudent.Size = new Size(130, 34);
            btnNavStudent.TabIndex = 1;
            btnNavStudent.Text = "Siswa";
            //
            // btnNavVisitor
            //
            btnNavVisitor.Location = new Point(358, 16);
            btnNavVisitor.Name = "btnNavVisitor";
            btnNavVisitor.Size = new Size(130, 34);
            btnNavVisitor.TabIndex = 2;
            btnNavVisitor.Text = "Pengunjung";
            //
            // pnlStudent
            //
            pnlStudent.Controls.Add(dgvData);
            pnlStudent.Controls.Add(txtSearchStudent);
            pnlStudent.Controls.Add(pnlStudentCard);
            pnlStudent.Dock = DockStyle.Fill;
            pnlStudent.Name = "pnlStudent";
            pnlStudent.TabIndex = 1;
            //
            // pnlStudentCard
            //
            pnlStudentCard.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pnlStudentCard.Controls.Add(btnClearStudent);
            pnlStudentCard.Controls.Add(btnDeleteStudent);
            pnlStudentCard.Controls.Add(btnUpdateStudent);
            pnlStudentCard.Controls.Add(btnSave);
            pnlStudentCard.Controls.Add(txtAddress);
            pnlStudentCard.Controls.Add(lblAddress);
            pnlStudentCard.Controls.Add(txtClass);
            pnlStudentCard.Controls.Add(lblClass);
            pnlStudentCard.Controls.Add(txtNIS);
            pnlStudentCard.Controls.Add(label2);
            pnlStudentCard.Controls.Add(txtName);
            pnlStudentCard.Controls.Add(label1);
            pnlStudentCard.Location = new Point(20, 20);
            pnlStudentCard.Name = "pnlStudentCard";
            pnlStudentCard.Size = new Size(920, 150);
            pnlStudentCard.TabIndex = 0;
            //
            // label1
            //
            label1.AutoSize = true;
            label1.Location = new Point(20, 16);
            label1.Name = "label1";
            label1.Text = "Nama Siswa";
            //
            // txtName
            //
            txtName.Location = new Point(20, 40);
            txtName.Name = "txtName";
            txtName.PlaceholderText = "masukan nama....";
            txtName.Size = new Size(205, 27);
            txtName.TabIndex = 1;
            //
            // label2
            //
            label2.AutoSize = true;
            label2.Location = new Point(245, 16);
            label2.Name = "label2";
            label2.Text = "Nomor Induk Siswa (NIS)";
            //
            // txtNIS
            //
            txtNIS.Location = new Point(245, 40);
            txtNIS.Name = "txtNIS";
            txtNIS.PlaceholderText = "masukan nis....";
            txtNIS.Size = new Size(205, 27);
            txtNIS.TabIndex = 2;
            //
            // lblClass
            //
            lblClass.AutoSize = true;
            lblClass.Location = new Point(470, 16);
            lblClass.Name = "lblClass";
            lblClass.Text = "Kelas";
            //
            // txtClass
            //
            txtClass.Location = new Point(470, 40);
            txtClass.Name = "txtClass";
            txtClass.PlaceholderText = "contoh: XII RPL 1";
            txtClass.Size = new Size(205, 27);
            txtClass.TabIndex = 3;
            //
            // lblAddress
            //
            lblAddress.AutoSize = true;
            lblAddress.Location = new Point(695, 16);
            lblAddress.Name = "lblAddress";
            lblAddress.Text = "Alamat";
            //
            // txtAddress
            //
            txtAddress.Location = new Point(695, 40);
            txtAddress.Name = "txtAddress";
            txtAddress.PlaceholderText = "masukan alamat....";
            txtAddress.Size = new Size(205, 27);
            txtAddress.TabIndex = 4;
            //
            // btnSave
            //
            btnSave.Location = new Point(20, 94);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(110, 36);
            btnSave.TabIndex = 5;
            btnSave.Text = "Simpan";
            //
            // btnUpdateStudent
            //
            btnUpdateStudent.Location = new Point(140, 94);
            btnUpdateStudent.Name = "btnUpdateStudent";
            btnUpdateStudent.Size = new Size(110, 36);
            btnUpdateStudent.TabIndex = 6;
            btnUpdateStudent.Text = "Update";
            //
            // btnDeleteStudent
            //
            btnDeleteStudent.Location = new Point(260, 94);
            btnDeleteStudent.Name = "btnDeleteStudent";
            btnDeleteStudent.Size = new Size(110, 36);
            btnDeleteStudent.TabIndex = 7;
            btnDeleteStudent.Text = "Hapus";
            //
            // btnClearStudent
            //
            btnClearStudent.Location = new Point(380, 94);
            btnClearStudent.Name = "btnClearStudent";
            btnClearStudent.Size = new Size(110, 36);
            btnClearStudent.TabIndex = 8;
            btnClearStudent.Text = "Reset";
            //
            // txtSearchStudent
            //
            txtSearchStudent.Location = new Point(20, 188);
            txtSearchStudent.Name = "txtSearchStudent";
            txtSearchStudent.PlaceholderText = "cari nama / NIS / kelas...";
            txtSearchStudent.Size = new Size(320, 27);
            txtSearchStudent.TabIndex = 1;
            //
            // dgvData
            //
            dgvData.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvData.Location = new Point(20, 228);
            dgvData.Name = "dgvData";
            dgvData.Size = new Size(920, 328);
            dgvData.TabIndex = 2;
            //
            // pnlVisitor
            //
            pnlVisitor.Controls.Add(dgvVisitors);
            pnlVisitor.Controls.Add(pnlVisitorCard);
            pnlVisitor.Dock = DockStyle.Fill;
            pnlVisitor.Name = "pnlVisitor";
            pnlVisitor.TabIndex = 2;
            pnlVisitor.Visible = false;
            //
            // pnlVisitorCard
            //
            pnlVisitorCard.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pnlVisitorCard.Controls.Add(btnClearVisitor);
            pnlVisitorCard.Controls.Add(btnDeleteVisitors);
            pnlVisitorCard.Controls.Add(btnUpdateVisitors);
            pnlVisitorCard.Controls.Add(btnSaveVisitors);
            pnlVisitorCard.Controls.Add(txtInstitution);
            pnlVisitorCard.Controls.Add(label4);
            pnlVisitorCard.Controls.Add(txtVisitors);
            pnlVisitorCard.Controls.Add(label3);
            pnlVisitorCard.Location = new Point(20, 20);
            pnlVisitorCard.Name = "pnlVisitorCard";
            pnlVisitorCard.Size = new Size(920, 150);
            pnlVisitorCard.TabIndex = 0;
            //
            // label3
            //
            label3.AutoSize = true;
            label3.Location = new Point(20, 16);
            label3.Name = "label3";
            label3.Text = "Nama Pengunjung";
            //
            // txtVisitors
            //
            txtVisitors.Location = new Point(20, 40);
            txtVisitors.Name = "txtVisitors";
            txtVisitors.PlaceholderText = "masukan visitors...";
            txtVisitors.Size = new Size(300, 27);
            txtVisitors.TabIndex = 1;
            //
            // label4
            //
            label4.AutoSize = true;
            label4.Location = new Point(345, 16);
            label4.Name = "label4";
            label4.Text = "Institusi";
            //
            // txtInstitution
            //
            txtInstitution.Location = new Point(345, 40);
            txtInstitution.Name = "txtInstitution";
            txtInstitution.PlaceholderText = "masukan institusi...";
            txtInstitution.Size = new Size(300, 27);
            txtInstitution.TabIndex = 2;
            //
            // btnSaveVisitors
            //
            btnSaveVisitors.Location = new Point(20, 94);
            btnSaveVisitors.Name = "btnSaveVisitors";
            btnSaveVisitors.Size = new Size(110, 36);
            btnSaveVisitors.TabIndex = 3;
            btnSaveVisitors.Text = "Simpan";
            //
            // btnUpdateVisitors
            //
            btnUpdateVisitors.Location = new Point(140, 94);
            btnUpdateVisitors.Name = "btnUpdateVisitors";
            btnUpdateVisitors.Size = new Size(110, 36);
            btnUpdateVisitors.TabIndex = 4;
            btnUpdateVisitors.Text = "Update";
            //
            // btnDeleteVisitors
            //
            btnDeleteVisitors.Location = new Point(260, 94);
            btnDeleteVisitors.Name = "btnDeleteVisitors";
            btnDeleteVisitors.Size = new Size(110, 36);
            btnDeleteVisitors.TabIndex = 5;
            btnDeleteVisitors.Text = "Hapus";
            //
            // btnClearVisitor
            //
            btnClearVisitor.Location = new Point(380, 94);
            btnClearVisitor.Name = "btnClearVisitor";
            btnClearVisitor.Size = new Size(110, 36);
            btnClearVisitor.TabIndex = 6;
            btnClearVisitor.Text = "Reset";
            //
            // dgvVisitors
            //
            dgvVisitors.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvVisitors.Location = new Point(20, 188);
            dgvVisitors.Name = "dgvVisitors";
            dgvVisitors.Size = new Size(920, 368);
            dgvVisitors.TabIndex = 1;
            //
            // Form1
            //
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(960, 620);
            MinimumSize = new Size(800, 560);
            Controls.Add(pnlStudent);
            Controls.Add(pnlVisitor);
            Controls.Add(pnlNav);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "School App";
            ((System.ComponentModel.ISupportInitialize)dgvData).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvVisitors).EndInit();
            pnlNav.ResumeLayout(false);
            pnlNav.PerformLayout();
            pnlStudentCard.ResumeLayout(false);
            pnlStudentCard.PerformLayout();
            pnlStudent.ResumeLayout(false);
            pnlStudent.PerformLayout();
            pnlVisitorCard.ResumeLayout(false);
            pnlVisitorCard.PerformLayout();
            pnlVisitor.ResumeLayout(false);
            pnlVisitor.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlNav;
        private Label lblAppName;
        private Button btnNavStudent;
        private Button btnNavVisitor;
        private Panel pnlStudent;
        private Panel pnlVisitor;
        private Panel pnlStudentCard;
        private Panel pnlVisitorCard;

        private Label label1;
        private Label label2;
        private Label lblClass;
        private Label lblAddress;
        private TextBox txtName;
        private TextBox txtNIS;
        private TextBox txtClass;
        private TextBox txtAddress;
        private TextBox txtSearchStudent;
        private Button btnSave;
        private Button btnUpdateStudent;
        private Button btnDeleteStudent;
        private Button btnClearStudent;
        private DataGridView dgvData;

        private Label label3;
        private Label label4;
        private TextBox txtVisitors;
        private TextBox txtInstitution;
        private Button btnSaveVisitors;
        private Button btnUpdateVisitors;
        private Button btnDeleteVisitors;
        private Button btnClearVisitor;
        private DataGridView dgvVisitors;
    }
}
