using System.Drawing;
using System.Windows.Forms;

namespace SchoolApp
{
    public partial class Form1
    {
        // ===== Palet warna =====
        private static readonly Color Navy      = Color.FromArgb(30, 42, 74);
        private static readonly Color NavyLight = Color.FromArgb(48, 63, 105);
        private static readonly Color Amber     = Color.FromArgb(244, 185, 66);
        private static readonly Color PageBg    = Color.FromArgb(243, 245, 250);
        private static readonly Color CardBg    = Color.White;
        private static readonly Color InputBg   = Color.FromArgb(248, 250, 252);
        private static readonly Color TextMain  = Color.FromArgb(30, 41, 59);
        private static readonly Color TextMuted = Color.FromArgb(100, 116, 139);
        private static readonly Color Teal      = Color.FromArgb(15, 157, 143);
        private static readonly Color Blue      = Color.FromArgb(59, 100, 230);
        private static readonly Color Red       = Color.FromArgb(229, 72, 77);
        private static readonly Color Gray      = Color.FromArgb(226, 232, 240);
        private static readonly Color Line      = Color.FromArgb(226, 232, 240);

        private void ApplyTheme()
        {
            Font = new Font("Segoe UI", 10F);
            BackColor = PageBg;

            // Navigasi atas
            pnlNav.BackColor = Navy;
            lblAppName.Font = new Font("Segoe UI Semibold", 16F);
            lblAppName.ForeColor = Color.White;
            StyleButton(btnNavStudent, NavyLight, Color.White);
            StyleButton(btnNavVisitor, NavyLight, Color.White);

            // Halaman & kartu form
            pnlStudent.BackColor = PageBg;
            pnlVisitor.BackColor = PageBg;
            pnlStudentCard.BackColor = CardBg;
            pnlVisitorCard.BackColor = CardBg;

            foreach (Label l in new[] { label1, label2, lblClass, lblAddress, label3, label4 })
            {
                l.Font = new Font("Segoe UI Semibold", 9F);
                l.ForeColor = TextMuted;
            }

            foreach (TextBox t in new[] { txtName, txtNIS, txtClass, txtAddress,
                                          txtSearchStudent, txtVisitors, txtInstitution })
            {
                t.BorderStyle = BorderStyle.FixedSingle;
                t.BackColor = InputBg;
                t.ForeColor = TextMain;
            }

            // Tombol aksi
            StyleButton(btnSave, Teal, Color.White);
            StyleButton(btnSaveVisitors, Teal, Color.White);
            StyleButton(btnUpdateStudent, Blue, Color.White);
            StyleButton(btnUpdateVisitors, Blue, Color.White);
            StyleButton(btnDeleteStudent, Red, Color.White);
            StyleButton(btnDeleteVisitors, Red, Color.White);
            StyleButton(btnClearStudent, Gray, TextMain);
            StyleButton(btnClearVisitor, Gray, TextMain);

            StyleGrid(dgvData);
            StyleGrid(dgvVisitors);
        }

        private static void StyleButton(Button b, Color back, Color fore)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = back;
            b.ForeColor = fore;
            b.Font = new Font("Segoe UI Semibold", 9.5F);
            b.Cursor = Cursors.Hand;
            b.UseVisualStyleBackColor = false;
        }

        private static void StyleGrid(DataGridView g)
        {
            g.BackgroundColor = CardBg;
            g.BorderStyle = BorderStyle.None;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.GridColor = Line;
            g.EnableHeadersVisualStyles = false;
            g.RowHeadersVisible = false;
            g.ReadOnly = true;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.AllowUserToResizeRows = false;
            g.MultiSelect = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            g.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            g.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            g.ColumnHeadersHeight = 40;
            g.RowTemplate.Height = 34;

            g.ColumnHeadersDefaultCellStyle.BackColor = Navy;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 9.5F);
            g.ColumnHeadersDefaultCellStyle.SelectionBackColor = Navy;
            g.ColumnHeadersDefaultCellStyle.Padding = new Padding(8, 0, 0, 0);

            g.DefaultCellStyle.BackColor = CardBg;
            g.DefaultCellStyle.ForeColor = TextMain;
            g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(214, 242, 238);
            g.DefaultCellStyle.SelectionForeColor = TextMain;
            g.DefaultCellStyle.Padding = new Padding(8, 0, 0, 0);
            g.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
        }

        private void SetNavActive(Page page)
        {
            bool s = page == Page.Student;
            btnNavStudent.BackColor = s ? Amber : NavyLight;
            btnNavStudent.ForeColor = s ? Navy : Color.White;
            btnNavVisitor.BackColor = s ? NavyLight : Amber;
            btnNavVisitor.ForeColor = s ? Color.White : Navy;
        }
    }
}
