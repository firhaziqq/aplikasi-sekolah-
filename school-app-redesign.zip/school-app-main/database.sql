-- ============================================================
--  Database SchoolApp  (XAMPP / MariaDB / MySQL)
--  Cara pakai: phpMyAdmin -> tab "Import" -> pilih file ini -> Go
--  atau tempel isinya di tab "SQL" lalu klik Go.
-- ============================================================

CREATE DATABASE IF NOT EXISTS `pi_school`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE `pi_school`;

-- ---------- Tabel siswa ----------
CREATE TABLE IF NOT EXISTS `students` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nis`        VARCHAR(20)  NOT NULL,
  `name`       VARCHAR(100) NOT NULL,
  `class_name` VARCHAR(50)  NOT NULL,
  `address`    VARCHAR(255) NOT NULL DEFAULT '',
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_students_nis` (`nis`),      -- NIS tidak boleh kembar (error 1062)
  KEY `idx_students_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------- Tabel pengunjung ----------
CREATE TABLE IF NOT EXISTS `visitors` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `visitors`    VARCHAR(100) NOT NULL,
  `institution` VARCHAR(150) NOT NULL,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------- Data contoh (boleh dihapus) ----------
INSERT INTO `students` (`nis`, `name`, `class_name`, `address`) VALUES
  ('2024001', 'Ahmad Rizky',   'XII RPL 1', 'Jl. Merdeka No. 10'),
  ('2024002', 'Siti Nurhaliza', 'XII RPL 1', 'Jl. Melati No. 5'),
  ('2024003', 'Budi Santoso',  'XI TKJ 2',  'Jl. Kenanga No. 21');

INSERT INTO `visitors` (`visitors`, `institution`) VALUES
  ('Dewi Lestari', 'Dinas Pendidikan'),
  ('Rudi Hartono', 'PT Maju Jaya');
